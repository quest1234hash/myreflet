var {UserModel,LogDetailsModel}=require('../../models/user');
var {SecurityMasterModel,UserSecurityModel}=require('../../models/securityMaster');
var{ WalletModel,WalletModelImport } = require('../../models/wallets');
var {MyReflectIdModel, DocumentReflectIdModel,FilesDocModel} = require('../../models/reflect');
var {CountryModel,VerifierCategoryMasterModel,DocumentMasterModel} = require('../../models/master');
var {ClientVerificationModel,RequestDocumentsModel,RequestFilesModel} = require('../../models/request');
var { ComplaintModel,CommentModel} = require('../../models/complaint');
var { tbl_verifier_plan_master,tbl_verifier_doc_list} = require('../../models/admin');
var { tbl_verfier_purchase_details } =require("../../models/purchase_detaile")
var { tbl_address_book } =require("../../models/address_book")
var {NotificationModel}=require('../../models/notification');
var {
  MarketPlaceMsg
}=require('../../models/market_place')
const paginate = require("paginate-array");

var { decrypt, encrypt } = require('../../helpers/encrypt-decrypt')

var qr_func=require('../../helpers/qrcode');
var QRCode = require('qrcode');

const Op = require('sequelize').Op

const Tx = require('ethereumjs-tx')
const Web3 = require('web3');
// var web3 = new Web3(new Web3.providers.HttpProvider("https://ropsten.infura.io/v3/eda1216d6a374b3b861bf65556944cdb"));
// var web3 = new Web3(new Web3.providers.HttpProvider("https://mainnet.infura.io/v3/f8a10cc5a2684f61b0de4bf632dd4f4b"));
var web3 = new Web3(new Web3.providers.HttpProvider("http://13.233.173.250:8501"));

const nodemailer = require("nodemailer");
var db = require('../../services/database');
var sequelize = require('sequelize');
var dateTime = require('node-datetime')
var crypto = require('crypto');
var text_func=require('../../helpers/text');
var mail_func=require('../../helpers/mail');
const util = require('util');
const { base64encode, base64decode } = require('nodejs-base64');
const generateUniqueId = require('generate-unique-id');
var moment = require('moment');
var crypto = require('crypto'); 
var request = require('request');
const ejs = require('ejs');


//28-02-2020
const ipfsAPI = require('ipfs-api');
const fs = require('fs');
const ipfs = ipfsAPI('ipfs.infura.io', '5001', {protocol: 'https'})




exports.verifierDeshboard= async(req,res,next )=>{
  // console.log("check path   ",__dirname)
  // let testFile = fs.readFileSync(__dirname+'/../../uploads/documents/document_1582884940789_myw3schoolsimage.jpg');
  // let testBuffer = new Buffer(testFile);
  // ipfs.files.add(testBuffer, function (err, file) {
  //   if (err) {
  //     console.log("err from ejs",err);
  //   }
  //   console.log("from ipfs ",file)
  // })
    var page = req.query.page || 1
    var perPage = 10
    var userId =req.session.user_id 
  db.query('SELECT *  ,tbl_wallet_reflectid_rels.reflect_code as v_r_code ,tbl_wallet_reflectid_rels.reflectid_by as v_reflectid_by,tbl_wallet_reflectid_rels.rep_username as v_rep_username,tbl_wallet_reflectid_rels.entity_company_name as v_entity_company_name,tbl_client_verification_requests.createdAt as request_created FROM `tbl_client_verification_requests` INNER JOIN tbl_wallet_reflectid_rels ON tbl_wallet_reflectid_rels.reflect_id=tbl_client_verification_requests.verifer_my_reflect_id INNER JOIN tbl_wallet_reflectid_rels as c ON c.reflect_id=tbl_client_verification_requests.reflect_id INNER JOIN tbl_user_registrations ON tbl_user_registrations.reg_user_id=tbl_client_verification_requests.client_id LEFT JOIN tbl_countries ON c.entity_company_country=tbl_countries.country_id WHERE tbl_client_verification_requests.verifier_id="'+userId+'" AND tbl_client_verification_requests.deleted="0"',{type:db.QueryTypes.SELECT}).then(requestToverifier=>{

        db.query('SELECT * FROM tbl_user_registrations WHERE reg_user_id='+userId,{type:db.QueryTypes.SELECT}).then(userData=>{
          
                    db.query('SELECT *,tbl_wallet_reflectid_rels.reflect_code as v_r_code ,tbl_wallet_reflectid_rels.reflectid_by as v_reflectid_by,tbl_wallet_reflectid_rels.rep_username as v_rep_username,tbl_wallet_reflectid_rels.entity_company_name as v_entity_company_name FROM `tbl_sub_verifier_clients` INNER JOIN tbl_client_verification_requests ON tbl_client_verification_requests.request_id=tbl_sub_verifier_clients.client_request_id INNER JOIN tbl_wallet_reflectid_rels ON tbl_wallet_reflectid_rels.reflect_id=tbl_client_verification_requests.verifer_my_reflect_id INNER JOIN tbl_wallet_reflectid_rels as c ON c.reflect_id=tbl_client_verification_requests.reflect_id INNER JOIN tbl_user_registrations ON tbl_user_registrations.reg_user_id=tbl_client_verification_requests.client_id WHERE tbl_sub_verifier_clients.sub_verifier_reg_id="'+userId+'" AND tbl_sub_verifier_clients.deleted="0" AND tbl_sub_verifier_clients.sub_client_status="active" AND tbl_client_verification_requests.deleted="0"',{type:db.QueryTypes.SELECT}).then(subverifierAssignClient=>{

                             for (let i = 0; i < subverifierAssignClient.length; i++) {
                                                      requestToverifier.push(subverifierAssignClient[i])
                                            
                              }
                                const requestarray1 = paginate(requestToverifier, page, perPage); 
                                res.render('front/dashboard-verifier/v-deshboard',{
                                                                                   session : req.session,decrypt,
                                                                                    requestToverifierData :requestarray1,
                                                                                    verifierMyReflectId:requestToverifier,
                                                                                     moment,
                                                                                     userData
                                 })
                  })
      })
  })
//   console.log("......................verifierDeshboard start.................................")
//   var page = req.query.page || 1
//   var perPage = 10
//     var userId =req.session.user_id 
//     // console.log("user idv ", userId)
//     var requestarray =[]

//     await  CountryModel.findAll({where:{status:"active"}}).then(async(countryData)=>{

   
 
//     await ClientVerificationModel.findAll({where:{verifier_id: userId,deleted:"0",verifier_deleted :"0" } }).then(async(data)=>{
//       if(data!="" && data.length>0 && data!=undefined){
//          var count =1
//        /*outer loop Start*/
//          for(var i=0; i<data.length ;i++){
//             count++

//             UserModel.hasMany(MyReflectIdModel, {foreignKey: 'reg_user_id'})
//             MyReflectIdModel.belongsTo(UserModel, {foreignKey: 'reg_user_id'})
//             await MyReflectIdModel.findOne({where:{reflect_id:data[i].reflect_id} ,include: [UserModel]}).then(async(myRefdata)=>
//             {  
 
//                 UserModel.hasMany(MyReflectIdModel, {foreignKey: 'reg_user_id'})
//                MyReflectIdModel.belongsTo(UserModel, {foreignKey: 'reg_user_id'})
//                await MyReflectIdModel.findOne({where:{reflect_id:data[i].verifer_my_reflect_id },include: [UserModel]}).then(async(v_myRefdata)=>
//             {
//              // console.log(v_myRefdata.tbl_user_registration)
 
//              // console.log(".......................................................")
//              // console.log(v_myRefdata.tbl_user_registration.dataValues)
//             //  var match_to_client_or_veri ;
//             //      if(data[i].verifier_id==userId){
//             //        match_to_client_or_veri=data[i].verifier_id
//             //      }else{
//                 //    match_to_client_or_veri=data[i].client_id
//                 //  }
 
//              await UserModel.findOne({where:{reg_user_id:data[i].client_id }}).then(async(userdata)=>{

//                 await UserModel.findOne({where:{reg_user_id:data[i].verifier_id }}).then(async(ver_userdata)=>{
                

//                 var obj ={
//                    ClientVerificationData : data[i].dataValues,
//                    MyReflectIData :myRefdata.dataValues,
//                    user : userdata.dataValues,
//                    verifer_my_reflect_id_Data : v_myRefdata,
//                    ver_userdata :ver_userdata
//                   }

//                   requestarray.push(obj)
//                 })
//              })
 
 
//             })
           
 
//             })
//          }
//         /*outer loop End*/

//         //  console.log("requestarray***************** ", requestarray)
//          const requestarray1 = paginate(requestarray, page, perPage);         
//          console.log("requestarray***************** ", requestarray1)
//          res.render('front/dashboard-verifier/v-deshboard',{
//           session : req.session,
//           ClientVerificationModelData :requestarray1,
//           ClientVerificationModelforfilter: requestarray,
//           countryData,
//           moment
//    })
//     }else{
//       res.render('front/myReflect/my-reflet-id-code-new',{
//         success_msg:"",
//         err_msg:"",
//         session:req.session,
//         ejs
//        }); 
//     }
//      }).catch(err=>console.log("errr",err))
    
//     }).catch(err=>console.log("errr countryData",err))
// // res.render('front/user-on-boarding-request/boarding-request',{session:req.session})

}

  /**request_status_change Get method Start**/
exports.RequestAcceptReject=async(req,res,next)=>{

   var status = req.query.status
  var user_id=  req.session.user_id 
  var request_id = req.query.request_id
  var dt = dateTime.create();
   var formatted = dt.format('Y-m-d H:M:S');
  //  var msg= `Your request has been ${status}ed by verifier.`
   var ntf_type ;
   if(status=="accept"){
     ntf_type=2;
   }else{
     ntf_type=3
   }
 //  console.log("123......................<><><><<<>.........................................................")
 //  console.log(status)
 //  console.log(request_id)

 //  console.log(".............................<><><><.............................................")
 var useradata =await UserModel.findOne({where:{reg_user_id:user_id}})
  await ClientVerificationModel.update({request_status:status}, { where: { request_id:request_id }}).then(async(result) =>{
       // console.log(result)
       
       ClientVerificationModel.findOne({where:{request_id:request_id}}).then(async(requestdata)=>{
        var msg= `Your request has been ${status}ed by verifier ${decrypt(useradata.full_name)}-${requestdata.request_code}.`

         await NotificationModel.create({
           notification_msg   :   msg,
           sender_id          :  user_id,
           receiver_id        :  requestdata.client_id,
           request_id         :  request_id,
           notification_type  :   ntf_type,
           notification_date  : formatted,
           read_status        : "no"
          }).then(data=>{
            res.redirect("/verifier_deshboard")

          }).catch(err=>console.log("err",err))
       }).catch(err=>console.log("err",err))
 
   }).catch(err=>console.log("err",err))
}
/**request_status_change Get method End**/


exports.filter_requests= async(req,res,next )=>{
 
  console.log("......................verifierDeshboard start.................................")
  var page = req.query.page || 1
  var perPage = 10
  var userId =req.session.user_id 
  var searchvalue = req.body.searchvalue
   console.log("searchvalue...",searchvalue)
   var qre;
  if(searchvalue!=undefined)
                          {
                             qre='SELECT * ,tbl_wallet_reflectid_rels.reflect_code as v_r_code ,tbl_wallet_reflectid_rels.reflectid_by as v_reflectid_by,tbl_wallet_reflectid_rels.rep_username as v_rep_username,tbl_wallet_reflectid_rels.entity_company_name as v_entity_company_name FROM `tbl_client_verification_requests` INNER JOIN tbl_wallet_reflectid_rels ON tbl_wallet_reflectid_rels.reflect_id=tbl_client_verification_requests.verifer_my_reflect_id INNER JOIN tbl_wallet_reflectid_rels as c ON c.reflect_id=tbl_client_verification_requests.client_id INNER JOIN tbl_user_registrations ON tbl_user_registrations.reg_user_id=tbl_client_verification_requests.client_id LEFT JOIN tbl_countries ON c.entity_company_country=tbl_countries.country_id WHERE  (((tbl_client_verification_requests.verifier_id="'+userId+'") AND (tbl_client_verification_requests.deleted="0")) AND ( (tbl_user_registrations.email LIKE "%'+searchvalue+'%") OR (c.reflect_code LIKE "%'+searchvalue+'%") OR (tbl_wallet_reflectid_rels.reflect_code LIKE "%'+searchvalue+'%") OR (tbl_user_registrations.full_name LIKE "%'+searchvalue+'%") ))'

                                    subverfierClientUrl='SELECT *,tbl_wallet_reflectid_rels.reflect_code as v_r_code ,tbl_wallet_reflectid_rels.reflectid_by as v_reflectid_by,tbl_wallet_reflectid_rels.rep_username as v_rep_username,tbl_wallet_reflectid_rels.entity_company_name as v_entity_company_name FROM `tbl_sub_verifier_clients` INNER JOIN tbl_client_verification_requests ON tbl_client_verification_requests.request_id=tbl_sub_verifier_clients.client_request_id INNER JOIN tbl_wallet_reflectid_rels ON tbl_wallet_reflectid_rels.reflect_id=tbl_client_verification_requests.verifer_my_reflect_id INNER JOIN tbl_wallet_reflectid_rels as c ON c.reflect_id=tbl_client_verification_requests.client_id INNER JOIN tbl_user_registrations ON tbl_user_registrations.reg_user_id=tbl_client_verification_requests.client_id WHERE  (((tbl_sub_verifier_clients.sub_verifier_reg_id="'+userId+'") AND (tbl_client_verification_requests.deleted="0") AND (tbl_sub_verifier_clients.sub_client_status="active") AND (tbl_sub_verifier_clients.deleted="0")) AND ( (tbl_user_registrations.email LIKE "%'+searchvalue+'%") OR (c.reflect_code LIKE "%'+searchvalue+'%") OR (tbl_wallet_reflectid_rels.reflect_code LIKE "%'+searchvalue+'%") OR (tbl_user_registrations.full_name LIKE "%'+searchvalue+'%")))'

                           }
       else{
             reflect_code_list =  JSON.parse(req.body.reflect_code_list);
             var status_list   = JSON.parse(req.body.status_list);
                   if(status_list[0]!=null && reflect_code_list[0]!=null)
                            {      
                                   qre= 'SELECT * ,tbl_wallet_reflectid_rels.reflect_code as v_r_code ,tbl_wallet_reflectid_rels.reflectid_by as v_reflectid_by,tbl_wallet_reflectid_rels.rep_username as v_rep_username,tbl_wallet_reflectid_rels.entity_company_name as v_entity_company_name FROM `tbl_client_verification_requests` INNER JOIN tbl_wallet_reflectid_rels ON tbl_wallet_reflectid_rels.reflect_id=tbl_client_verification_requests.verifer_my_reflect_id INNER JOIN tbl_wallet_reflectid_rels as c ON c.reflect_id=tbl_client_verification_requests.client_id INNER JOIN tbl_user_registrations ON tbl_user_registrations.reg_user_id=tbl_client_verification_requests.client_id LEFT JOIN tbl_countries ON c.entity_company_country=tbl_countries.country_id WHERE tbl_client_verification_requests.verifier_id="'+userId+'" AND tbl_client_verification_requests.deleted="0" AND tbl_wallet_reflectid_rels.reflect_code IN ('+reflect_code_list+') AND tbl_client_verification_requests.request_status IN ('+status_list+')'

                                   

                                                          subverfierClientUrl ='SELECT *,tbl_wallet_reflectid_rels.reflect_code as v_r_code ,tbl_wallet_reflectid_rels.reflectid_by as v_reflectid_by,tbl_wallet_reflectid_rels.rep_username as v_rep_username,tbl_wallet_reflectid_rels.entity_company_name as v_entity_company_name FROM `tbl_sub_verifier_clients` INNER JOIN tbl_client_verification_requests ON tbl_client_verification_requests.request_id=tbl_sub_verifier_clients.client_request_id INNER JOIN tbl_wallet_reflectid_rels ON tbl_wallet_reflectid_rels.reflect_id=tbl_client_verification_requests.verifer_my_reflect_id INNER JOIN tbl_wallet_reflectid_rels as c ON c.reflect_id=tbl_client_verification_requests.client_id INNER JOIN tbl_user_registrations ON tbl_user_registrations.reg_user_id=tbl_client_verification_requests.client_id WHERE tbl_sub_verifier_clients.sub_verifier_reg_id="'+userId+'" AND tbl_sub_verifier_clients.deleted="0" AND tbl_sub_verifier_clients.sub_client_status="active" AND tbl_client_verification_requests.deleted="0" AND tbl_wallet_reflectid_rels.reflect_code IN ('+reflect_code_list+') AND tbl_client_verification_requests.request_status IN ('+status_list+')'
                             }
                       else{
         if(status_list[0]==null)
         {

             qre= 'SELECT * ,tbl_wallet_reflectid_rels.reflect_code as v_r_code ,tbl_wallet_reflectid_rels.reflectid_by as v_reflectid_by,tbl_wallet_reflectid_rels.rep_username as v_rep_username,tbl_wallet_reflectid_rels.entity_company_name as v_entity_company_name FROM `tbl_client_verification_requests` INNER JOIN tbl_wallet_reflectid_rels ON tbl_wallet_reflectid_rels.reflect_id=tbl_client_verification_requests.verifer_my_reflect_id INNER JOIN tbl_wallet_reflectid_rels as c ON c.reflect_id=tbl_client_verification_requests.client_id INNER JOIN tbl_user_registrations ON tbl_user_registrations.reg_user_id=tbl_client_verification_requests.client_id LEFT JOIN tbl_countries ON c.entity_company_country=tbl_countries.country_id WHERE tbl_client_verification_requests.verifier_id="'+userId+'" AND tbl_client_verification_requests.deleted="0" AND tbl_wallet_reflectid_rels.reflect_code IN ('+reflect_code_list+')'

                        subverfierClientUrl ='SELECT *,tbl_wallet_reflectid_rels.reflect_code as v_r_code ,tbl_wallet_reflectid_rels.reflectid_by as v_reflectid_by,tbl_wallet_reflectid_rels.rep_username as v_rep_username,tbl_wallet_reflectid_rels.entity_company_name as v_entity_company_name FROM `tbl_sub_verifier_clients` INNER JOIN tbl_client_verification_requests ON tbl_client_verification_requests.request_id=tbl_sub_verifier_clients.client_request_id INNER JOIN tbl_wallet_reflectid_rels ON tbl_wallet_reflectid_rels.reflect_id=tbl_client_verification_requests.verifer_my_reflect_id INNER JOIN tbl_wallet_reflectid_rels as c ON c.reflect_id=tbl_client_verification_requests.client_id INNER JOIN tbl_user_registrations ON tbl_user_registrations.reg_user_id=tbl_client_verification_requests.client_id WHERE tbl_sub_verifier_clients.sub_verifier_reg_id="'+userId+'" AND tbl_sub_verifier_clients.deleted="0" AND tbl_sub_verifier_clients.sub_client_status="active" AND tbl_client_verification_requests.deleted="0" AND tbl_wallet_reflectid_rels.reflect_code IN ('+reflect_code_list+')'
  
         }
         if(reflect_code_list[0]==null)
          {
   
            qre= 'SELECT * ,tbl_wallet_reflectid_rels.reflect_code as v_r_code ,tbl_wallet_reflectid_rels.reflectid_by as v_reflectid_by,tbl_wallet_reflectid_rels.rep_username as v_rep_username,tbl_wallet_reflectid_rels.entity_company_name as v_entity_company_name FROM `tbl_client_verification_requests` INNER JOIN tbl_wallet_reflectid_rels ON tbl_wallet_reflectid_rels.reflect_id=tbl_client_verification_requests.verifer_my_reflect_id INNER JOIN tbl_wallet_reflectid_rels as c ON c.reflect_id=tbl_client_verification_requests.client_id INNER JOIN tbl_user_registrations ON tbl_user_registrations.reg_user_id=tbl_client_verification_requests.client_id LEFT JOIN tbl_countries ON c.entity_company_country=tbl_countries.country_id WHERE tbl_client_verification_requests.verifier_id="'+userId+'" AND tbl_client_verification_requests.deleted="0" AND tbl_client_verification_requests.request_status IN ('+status_list+')'

                                  subverfierClientUrl ='SELECT *,tbl_wallet_reflectid_rels.reflect_code as v_r_code ,tbl_wallet_reflectid_rels.reflectid_by as v_reflectid_by,tbl_wallet_reflectid_rels.rep_username as v_rep_username,tbl_wallet_reflectid_rels.entity_company_name as v_entity_company_name FROM `tbl_sub_verifier_clients` INNER JOIN tbl_client_verification_requests ON tbl_client_verification_requests.request_id=tbl_sub_verifier_clients.client_request_id INNER JOIN tbl_wallet_reflectid_rels ON tbl_wallet_reflectid_rels.reflect_id=tbl_client_verification_requests.verifer_my_reflect_id INNER JOIN tbl_wallet_reflectid_rels as c ON c.reflect_id=tbl_client_verification_requests.client_id INNER JOIN tbl_user_registrations ON tbl_user_registrations.reg_user_id=tbl_client_verification_requests.client_id WHERE tbl_sub_verifier_clients.sub_verifier_reg_id="'+userId+'" AND tbl_sub_verifier_clients.deleted="0" AND tbl_sub_verifier_clients.sub_client_status="active" AND tbl_client_verification_requests.deleted="0" AND tbl_client_verification_requests.request_status IN ('+status_list+')'

          }

       }
           }



            db.query(qre,{type:db.QueryTypes.SELECT}).then(requestToverifier =>{
                 db.query(subverfierClientUrl,{type:db.QueryTypes.SELECT}).then(subverifierAssignClient=>{

                              for (let i = 0; i < subverifierAssignClient.length; i++) {
                                                                                        requestToverifier.push(subverifierAssignClient[i])
                                             
                               }
                                 const requestarray1 = paginate(requestToverifier, page, perPage); 
                                 res.render('front/dashboard-verifier/verifierDeshboardFilter',{
                                                                                                 session : req.session,
                                                                                                 requestToverifierData :requestarray1,decrypt,
                                                                                                //  verifierMyReflectId:requestToverifier,
                                                                                                 moment,
                                                                                                //  userData
                                  })
                   })                
              })
//      // console.log("user idv ", userId)
//      var requestarray =[]

 

//    var reflect_code_list=[]
//    var filterArray =[]

//    reflect_code_list =  JSON.parse(req.body.reflect_code_list);
//    var status_list   = JSON.parse(req.body.status_list);
//    console.log("status_list.",status_list)
//    var objStatus;
//    if(status_list[0]==null){

//     objStatus= {verifier_id: userId ,
//                 deleted:"0" ,
//                 verifier_deleted :"0"
//               }
   
//    }else{
//     objStatus= {verifier_id: userId,
//                 deleted:"0",
//                 verifier_deleted :"0",
//                request_status: {
//                            [Op.or]: status_list
//                          },
//                }
   
//      }

//    await  CountryModel.findAll({where:{status:"active"}}).then(async(countryData)=>{

//      await ClientVerificationModel.findAll({where: objStatus }).then(async(data)=>{
//           var count =1
//         /*outer loop Start*/
//           for(var i=0; i<data.length ;i++){
//              count++


//              UserModel.hasMany(MyReflectIdModel, {foreignKey: 'reg_user_id'})
//              MyReflectIdModel.belongsTo(UserModel, {foreignKey: 'reg_user_id'})
//              await MyReflectIdModel.findOne({where:{reflect_id:data[i].reflect_id },include: [UserModel]}).then(async(myRefdata)=>
//              {  
 
//                  UserModel.hasMany(MyReflectIdModel, {foreignKey: 'reg_user_id'})
//                 MyReflectIdModel.belongsTo(UserModel, {foreignKey: 'reg_user_id'})
//                 await MyReflectIdModel.findOne({where:{reflect_id:data[i].verifer_my_reflect_id },include: [UserModel]}).then(async(v_myRefdata)=>
//              {
            
 
//               await UserModel.findOne({where:{reg_user_id:data[i].client_id }}).then(async(userdata)=>{

//                  await UserModel.findOne({where:{reg_user_id:data[i].verifier_id }}).then(async(ver_userdata)=>{

//                  var obj ={
//                     ClientVerificationData : data[i].dataValues,
//                     MyReflectIData :myRefdata.dataValues,
//                     user : userdata.dataValues,
//                     verifer_my_reflect_id_Data : v_myRefdata,
//                     ver_userdata :ver_userdata,
//                     countryData
//                    }

//                    requestarray.push(obj)
//                  })
//               })
 
 
//              })
           
 
//              })


//           }
//          /*outer loop End*/
        
//            /*loop-2 Start*/
//            var testCount = reflect_code_list.length
//           //  console.log("length...",testCount)
//            if(reflect_code_list[0]!=null){
//             for(var j=0; j<reflect_code_list.length ;j++)
//             {
//                   /*loop-3 Start*/
//                                  testCount--
//                          for(var k=0; k<requestarray.length ;k++){   
                  
//                                  if(requestarray[k].MyReflectIData.reflect_code==reflect_code_list[j]){
//                                                                                                      filterArray.push(requestarray[k])
//                                                   }
           
                
//                                }
//                   /*loop-3 Start*/
//                   if(testCount==0){
//                      console.log("j length...",j)
//                     //  console.log("testCount...",testCount)
//                      const requestarray1 = paginate(filterArray, page, perPage);         
//                      console.log("requestarray1***************** ", requestarray1)
//                      res.render('front/dashboard-verifier/verifierDeshboardFilter',{
//                       session : req.session,
//                       ClientVerificationModelData :requestarray1,
//                       // ClientVerificationModelforfilter: requestarray,
//                       countryData,
//                       moment
//                })
//                     //  res.send(filterArray)
//                     }
           
//             }
//            }else{
//             const requestarray1 = paginate(requestarray, page, perPage);         
//              console.log("requestarray***************** ", requestarray1)
//              res.render('front/dashboard-verifier/verifierDeshboardFilter',{
//               session : req.session,
//               ClientVerificationModelData :requestarray1,
//               // ClientVerificationModelforfilter: requestarray,
//               countryData,
//               moment
//        })
//               //  res.send(requestarray)
//            }

//  /*loop-2 Start*/
 
//    //        res.render('front/dashboard-verifier/v-deshboard',{
//    //         session : req.session,
//    //         ClientVerificationModelData :requestarray,
//    //         moment
//    //  })
 
//       }).catch(err=>console.log("errr",err))



//    })

// res.render('front/user-on-boarding-request/boarding-request',{session:req.session})

}

   /**request_status_change Get method Start**/
exports.multipalRequestReject=async(req,res,next)=>{

   var status = req.body.status
  var user_id=  req.session.user_id 
  // var request_id = req.query.request_id
  var request_ids =  JSON.parse(req.body.request_ids);

  var dt = dateTime.create();
   var formatted = dt.format('Y-m-d H:M:S');
  //  var msg= `Your request has been ${status} by verifier.`
   var ntf_type ;
   var updateObj
   if(status=="accept"){
    
     ntf_type=2;
   }
   if(status=="reject"){
     ntf_type=3
   }
   if(status=="delete"){
    ntf_type=5
  }
  if(status=="delete"){
    updateObj={ verifier_deleted :"1"}
  }else{
    
        updateObj={request_status:status}
  }
 //  console.log("123......................<><><><<<>.........................................................")
 //  console.log(status)
 //  console.log(request_id)

 //  console.log(".............................<><><><.............................................")
 var useradata =await UserModel.findOne({where:{reg_user_id:user_id}})

for(var i=0; i<request_ids.length; i++){
  await ClientVerificationModel.update(updateObj, { where: { request_id:request_ids[i] }}).then(async(result) =>{
       // console.log(result)
       ClientVerificationModel.findOne({where:{request_id:request_ids[i]}}).then(async(requestdata)=>{
        var msg= `Your request has been ${status}ed by verifier ${decrypt(useradata.full_name)}-${requestdata.request_code}.`

         await NotificationModel.create({
           notification_msg   :   msg,
           sender_id          :  user_id,
           receiver_id        :  requestdata.client_id,
           request_id         :  request_ids[i],
           notification_type  :   ntf_type,
           notification_date  : formatted,
           read_status        : "no"
          }).then(data=>{
            res.redirect("/verifier_deshboard")

          }).catch(err=>console.log("err",err))
       }).catch(err=>console.log("err",err))
 
   }).catch(err=>console.log("err",err))
  }

  if((request_ids.length-1)==i){
    res.send("done")
  }
}
/**request_status_change Get method End**/

/**********************************************************client deshboard start****************************************************************************/
exports.clientDeshboard= async(req,res,next )=>{
  console.log("******************cleint dashboard start******************************************************")
  var user_type = req.session.user_type;
  var user_id=req.session.user_id;
  var userId =req.session.user_id 
  var all_reflect_id=[]
  var msgArray=[]
    // var qr_url='data';
  if(user_id)
    {
               var user_type=req.session.user_type;
        
                    //  await MarketPlaceMsg.findAll({where:{receiver_id:userId}})
        //              await db.query("select * from tbl_market_place_msgs WHERE sender_id="+userId+" OR receiver_id="+userId,{ type:db.QueryTypes.SELECT})
        //              .then( async(msgData)=>{
                        
        // filtered = msgData.reduce((filtered, item) => {
        //   if( !filtered.some(filteredItem => JSON.stringify(filteredItem.receiver_id) == JSON.stringify(item.receiver_id)) )
        //     filtered.push(item)
        //   return filtered
        //   }, [])

        //   for(var f=0 ;f<filtered.length;f++){
        //    await MarketPlaceMsg.findAll({where:{receiver_id:filtered[f].receiver_id}}).then(async(msgDatalast)=>{
        //       await db.query("select * from tbl_wallet_reflectid_rels inner join tbl_user_registrations ON tbl_wallet_reflectid_rels.reg_user_id=tbl_user_registrations.reg_user_id WHERE tbl_wallet_reflectid_rels.reflect_id="+msgDatalast[msgDatalast.length-1].receiver_id,{ type:db.QueryTypes.SELECT}).then(async function(myreflectDataofMsg){
        //         var msgObj={
        //                        tblReflet :myreflectDataofMsg,
        //                        tblMsg    :msgDatalast[msgDatalast.length-1],
        //                   }
        //         msgArray.push(msgObj)
        //       })
              
        //     
        //   }
    var page = req.query.page || 1
    var perPage = 10;
    var page_data=[]
    var verifier_array=[]

   db.query("SELECT *from tbl_wallet_reflectid_rels inner join tbl_user_registrations  ON tbl_wallet_reflectid_rels.reg_user_id= tbl_user_registrations.reg_user_id WHERE user_as='verifier' and  tbl_user_registrations.reg_user_id <>"+userId,{ type:db.QueryTypes.SELECT}).then(async function(verifiers){

     for(var i=0;i<verifiers.length;i++){
                            await db.query('SELECT count(*) as total from tbl_myreflectid_doc_rels where reflect_id='+verifiers[i].reflect_id,{ type:db.QueryTypes.SELECT}).then(async function(verifier_docs){
                                // console.log("verifier_docs------------- ",verifier_docs)
                                await db.query('SELECT count(*) as verified from tbl_myreflectid_doc_rels where admin_status="verified" AND reflect_id='+verifiers[i].reflect_id,{ type:db.QueryTypes.SELECT}).then(function(verified_docs){
                                    // console.log("verified_docs------------- ",verified_docs)
                                    if(verifier_docs[0].total==verified_docs[0].verified && verifier_docs[0].total != 0){
                                        verifier_array.push(verifiers[i]);
                                    }
                                })
                            })
                        }
                      })
 await db.query("select *from tbl_msg_requests inner join tbl_wallet_reflectid_rels on tbl_wallet_reflectid_rels.reflect_id=tbl_msg_requests.reflect_id  WHERE tbl_msg_requests.create_sender_id="+userId+" order by request_msg_id desc",{ type:db.QueryTypes.SELECT}).then( async(verifiers)=>{

               for(var i=0;i< verifiers.length;i++)
               {
                 var request_msg_id = verifiers[i].request_msg_id;

                //  console.log('request_msg_id : ',request_msg_id)


                      await db.query("SELECT * FROM tbl_verifier_to_client_msgs where msg_id in (SELECT max(msg_id) FROM tbl_verifier_to_client_msgs group by request_msg_id having request_msg_id="+request_msg_id+" ) order by msg_id desc",{ type:db.QueryTypes.SELECT}).then( async(msg_verifiers)=>{


                               if(msg_verifiers.length>0)
                               {
                                verifiers[i].message_data = msg_verifiers
                              

                               }
                               else
                               {
                                             verifiers[i].message_data = 'undefined'

                                }
                    
                         })


               }



                //  console.log("verifiers ",verifiers)
                        if (verifiers.length > 0) {

                                page_data=verifiers
                     
                            }


                    const client_message_list = paginate(page_data,page, perPage);

              


                             db.query("SELECT * from tbl_wallet_reflectid_rels inner join tbl_user_wallets ON tbl_wallet_reflectid_rels.wallet_id=tbl_user_wallets.wallet_id inner join tbl_user_registrations on     tbl_user_registrations.reg_user_id=tbl_user_wallets.reg_user_id    WHERE  tbl_wallet_reflectid_rels.reg_user_id="+user_id+" and user_as='"+user_type+"'",{type:db.QueryTypes.SELECT}).then(async function(myreflectData){

                        if(myreflectData.length>0){
                               await db.query("select * from tbl_wallet_reflectid_rels inner join tbl_user_wallets ON tbl_wallet_reflectid_rels.wallet_id=tbl_user_wallets.wallet_id WHERE reflectid_by!='digitalWallet' and tbl_wallet_reflectid_rels.user_as='"+user_type+"' and tbl_wallet_reflectid_rels.reg_user_id="+user_id,{ type:db.QueryTypes.SELECT}).then(async function(walletdetails){
                                 
     
                               /*Loop Start*/
                              for(var i=0; i<walletdetails.length; i++){
     
                
                          // var testbell ;
                         await  web3.eth.getBalance(walletdetails[i].wallet_address).then((res_bal)=>{ 
                         //  console.log("js balcnce test" ,res_bal)
                         //  testbell=res_bal
                                             const etherValue = web3.utils.fromWei(res_bal, 'ether')

                         walletdetails[i].wal_balan =  etherValue    
                        });
                      
                            }
                          /*Loop End*/
                               var requestarray =[]
     
                                  await ClientVerificationModel.findAll({where:{ [Op.or]: [{verifier_id: userId} , {client_id: userId} ]} }).then    (async(data)=>{
                              //  console.log(".......................................................")
                                 var count =1
                        /*loop-1 Start*/
                            for(var i=0; i<data.length ;i++){
                             count++
                                 await MyReflectIdModel.findOne({where:{reflect_id:data[i].reflect_id }}).then(async(myRefdata)=>
                           {  
           
                          await db.query('SELECT * FROM `tbl_wallet_reflectid_rels` INNER JOIN tbl_user_registrations ON tbl_user_registrations.reg_user_id=tbl_wallet_reflectid_rels.reg_user_id WHERE tbl_wallet_reflectid_rels.deleted="0" AND tbl_wallet_reflectid_rels.reflect_id='+data[i].verifer_my_reflect_id,{type:db.QueryTypes.SELECT})
                        //   UserModel.hasMany(MyReflectIdModel, {foreignKey: 'reg_user_id'})
                        //  MyReflectIdModel.belongsTo(UserModel, {foreignKey: 'reg_user_id'})
                        //  await MyReflectIdModel.findOne({where:{reflect_id:data[i].verifer_my_reflect_id },include: [UserModel]})
                         .then(async(v_myRefdata)=>
                               {
                      //  console.log("@@@@@@@@@@@@@@@@@@@@@@@",v_myRefdata)
           
                       // console.log(".......................................................")
                       // console.log(v_myRefdata.tbl_user_registration.dataValues)
                           var match_to_client_or_veri ;
                           if(data[i].verifier_id==userId){
                             match_to_client_or_veri=data[i].verifier_id
                           }else{
                             match_to_client_or_veri=data[i].client_id
                           }
           
                             await UserModel.findOne({where:{reg_user_id:match_to_client_or_veri }}).then(userdata=>{
                          var obj ={
                                      ClientVerificationData : data[i].dataValues,
                                       MyReflectIData :myRefdata.dataValues,
                                       user : userdata.dataValues,
                                       verifer_my_reflect_id_Data : v_myRefdata
                         }
                            requestarray.push(obj)
                         
                                 })
           
           
                                 })
                     
           
                                    })
                           }
                          /*loop-1 End*/
           
                           //console.log("user idvddsvdsvdsvdsvds<><> ", verifer_my_reflect_id_Data)
           
                              // console.log("msg msgData",msgData)
                              // console.log("msg filtered",filtered)

                              // console.log("msg msgArray verifier_array",verifier_array)

                               res.render('front/dashboard_client/dashboard_client',{ web3,walletdetails,
                                                                         session:req.session,qr_func,decrypt,
                                                                         base64encode,
                                                                         ClientVerificationModelData :requestarray,
                                                                         myreflectData,
                                                                         verifiers_message_list:client_message_list,user_id,moment,verifier_array
                                                                         // msgArray
                                 })
           
                              }).catch(err=>console.log("errr",err))
     
                                  // res.render('front/dashboard_client/dashboard_client',{ web3,walletdetails,session:req.session,qr_func,base64encode,ClientVerificationModelData :requestarray,
                                 //   moment })
                             });
                                  }else{
                                           res.render('front/myReflect/my-reflet-id-code-new',{
                                                               success_msg:"",
                                                               err_msg:"",
                                                               session:req.session,
                                                                   ejs
                                            }); 
                                        }
                                      })
                                               // }).catch(err=>{console.log("msg err",err)})
       
                                               })
                                              }
                                      else
                                            {
                                            res.redirect('/login');
                                           }
                   
  
}
// exports.clientDeshboard= async(req,res,next )=>{
 
//   var user_type = req.session.user_type;
//   var user_id=req.session.user_id;
//   var userId =req.session.user_id 
//   var all_reflect_id=[]
//  var msgArray=[]
//     // var qr_url='data';
//     if(user_id)
//     {

//         var user_type=req.session.user_type;
//         // console.log("user type"+user_type); SELECT * FROM tbl_market_place_msgs WHERE 1
//       //  await MarketPlaceMsg.findAll({where:{sender_id:"user_id"}}).then( async(msgData)=>{

//       //     var filtered = msgData.reduce((filtered, item) => {
//       //       if( !filtered.some(filteredItem => JSON.stringify(filteredItem.receiver_id) == JSON.stringify(item.receiver_id)) )
//       //         filtered.push(item)
//       //       return filtered
//       //       }, [])

//       //       for(var f=0 ;f<filtered.length;f++){
//       //         MarketPlaceMsg.findAll({where:{receiver_id:filtered[f]}}).then(msgDatalast=>{
//       //           msgArray.push(msgDatalast[msgDatalast.length-1])
//       //         })
//       //       }

//           db.query("SELECT * from tbl_wallet_reflectid_rels inner join tbl_user_wallets ON tbl_wallet_reflectid_rels.wallet_id=tbl_user_wallets.wallet_id inner join tbl_user_registrations on     tbl_user_registrations.reg_user_id=tbl_user_wallets.reg_user_id    WHERE  tbl_wallet_reflectid_rels.reg_user_id="+user_id+" and user_as='"+user_type+"'",{type:db.QueryTypes.SELECT}).then(async function(myreflectData){

//           if(myreflectData.length>0){
//             await db.query("select * from tbl_wallet_reflectid_rels inner join tbl_user_wallets ON tbl_wallet_reflectid_rels.wallet_id=tbl_user_wallets.wallet_id WHERE tbl_wallet_reflectid_rels.user_as='"+user_type+"' and tbl_wallet_reflectid_rels.reg_user_id="+user_id,{ type:db.QueryTypes.SELECT}).then(async function(walletdetails){
     
//               /*Loop Start*/
//                for(var i=0; i<walletdetails.length; i++){
     
                
//                  // var testbell ;
//                     await  web3.eth.getBalance(walletdetails[i].wallet_address).then((res_bal)=>{ 
//                          //  console.log("js balcnce test" ,res_bal)
//                          //  testbell=res_bal
//                          walletdetails[i].wal_balan =  res_bal    
//                        });
                      
//                }
//               /*Loop End*/
//               var requestarray =[]
     
//               await ClientVerificationModel.findAll({where:{ [Op.or]: [{verifier_id: userId} , {client_id: userId} ]} }).then(async(data)=>{
//                    console.log(".......................................................")
//                    var count =1
//                    /*loop-1 Start*/
//                    for(var i=0; i<data.length ;i++){
//                       count++
//                       await MyReflectIdModel.findOne({where:{reflect_id:data[i].reflect_id }}).then(async(myRefdata)=>
//                       {  
           
//                           UserModel.hasMany(MyReflectIdModel, {foreignKey: 'reg_user_id'})
//                          MyReflectIdModel.belongsTo(UserModel, {foreignKey: 'reg_user_id'})
//                          await MyReflectIdModel.findOne({where:{reflect_id:data[i].verifer_my_reflect_id },include: [UserModel]}).then(async(v_myRefdata)=>
//                       {
//                        // console.log(v_myRefdata.tbl_user_registration)
           
//                        // console.log(".......................................................")
//                        // console.log(v_myRefdata.tbl_user_registration.dataValues)
//                        var match_to_client_or_veri ;
//                            if(data[i].verifier_id==userId){
//                              match_to_client_or_veri=data[i].verifier_id
//                            }else{
//                              match_to_client_or_veri=data[i].client_id
//                            }
           
//                        await UserModel.findOne({where:{reg_user_id:match_to_client_or_veri }}).then(userdata=>{
//                           var obj ={
//                              ClientVerificationData : data[i].dataValues,
//                              MyReflectIData :myRefdata.dataValues,
//                              user : userdata.dataValues,
//                              verifer_my_reflect_id_Data : v_myRefdata
//                             }
//                             requestarray.push(obj)
                         
//                        })
           
           
//                       })
                     
           
//                       })
//                    }
//                    /*loop-1 End*/
           
//                    //console.log("user idvddsvdsvdsvdsvds<><> ", verifer_my_reflect_id_Data)
           
//                   //  console.log("msg msgData",msgData)
//                   //  console.log("msg filtered",filtered)

//                   //  console.log("msg data",msgArray)

//                    res.render('front/dashboard_client/dashboard_client',{ web3,walletdetails,
//                                                                          session:req.session,qr_func,
//                                                                          base64encode,
//                                                                          ClientVerificationModelData :requestarray,
//                                                                          myreflectData,
//                                                                          moment ,
//                                                                          msgArray
//                                                                        })
           
//                }).catch(err=>console.log("errr",err))
     
//                  // res.render('front/dashboard_client/dashboard_client',{ web3,walletdetails,session:req.session,qr_func,base64encode,ClientVerificationModelData :requestarray,
//                  //   moment })
//              });
//             }else{
//               res.render('front/myReflect/my-reflet-id-code-new',{
//                 success_msg:"",
//                 err_msg:"",
//                 session:req.session,
//                 ejs
//                }); 
//             }
//             })
//         // }).catch(err=>{console.log("msg err",err)})
       
//     }
//     else
//     {
//         res.redirect('/login');
//     }
// // res.render('front/dashboard_client/dashboard_client',{session:req.session})

// }

exports.client_deshboard_search = async (req ,res ,next) =>{

  var user_type      = req.session.user_type;
  var user_id        = req.session.user_id;
  var reflect_code   = req.body.reflect_code;
  var session        = req.session
  console.log("reflect_code>>>>>>>>>>>>>>>>>>>>>>",reflect_code)

  await db
  
  .query("select * from tbl_wallet_reflectid_rels inner join tbl_user_wallets ON tbl_wallet_reflectid_rels.wallet_id=tbl_user_wallets.wallet_id WHERE reflectid_by!='digitalWallet' and tbl_wallet_reflectid_rels.user_as='"+user_type+"' and tbl_wallet_reflectid_rels.reg_user_id="+user_id+" AND tbl_wallet_reflectid_rels.reflect_code LIKE '%"+reflect_code+"%'",{ type:db.QueryTypes.SELECT})
  
  .then(async function(walletdetails){
                                 
     
         
        for(var i=0; i<walletdetails.length; i++){

        await  web3.eth.getBalance(walletdetails[i].wallet_address)

        .then((res_bal)=>{ 
    
                           const etherValue           =  web3.utils.fromWei(res_bal, 'ether')

                           walletdetails[i].wal_balan =  etherValue    
        });

        }

        res.render("front/dashboard_client/ajax_client_deshboard_search",{
                                                                                session,
                                                                                walletdetails,
                                                                                base64encode,decrypt
        })

   })

}